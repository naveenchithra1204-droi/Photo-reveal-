const floaties=document.getElementById('floaties');const floatEmojis=['💗','🌸','✨','🐾','🌷','💕'];function floatOne(){const e=document.createElement('span');e.className='floaty';e.textContent=floatEmojis[Math.floor(Math.random()*floatEmojis.length)];e.style.left=Math.random()*100+'%';e.style.animationDuration=(7+Math.random()*7)+'s';e.style.fontSize=(14+Math.random()*17)+'px';floaties.appendChild(e);setTimeout(()=>e.remove(),14500)}setInterval(floatOne,650);for(let i=0;i<10;i++)setTimeout(floatOne,i*220);
function showNote(){document.getElementById('note').classList.add('show');document.getElementById('note').scrollIntoView({behavior:'smooth',block:'nearest'});sprinkle('💌')};function closeNote(){document.getElementById('note').classList.remove('show')}
const lines=['Mreow! You look like someone who deserves a snack. 🍪','Breaking news: you are officially 100% pawsome. 🐾','Sending you one (1) imaginary kitten hug. 🐱','Reminder: drink some water and be kind to yourself 💛','I tried to be cool but I am literally a cat. 😹','You unlocked a tiny bit of joy! ✨'];function kittyDance(){const k=document.getElementById('kitty');k.classList.remove('dance');void k.offsetWidth;k.classList.add('dance');document.getElementById('speech').textContent=lines[Math.floor(Math.random()*lines.length)];for(let i=0;i<7;i++)setTimeout(()=>paw(k),i*75);sprinkle('🐾')}
function paw(k){const r=k.getBoundingClientRect();const p=document.createElement('span');p.className='paw';p.textContent=['🐾','💗','✨'][Math.floor(Math.random()*3)];p.style.left=(r.left+Math.random()*r.width)+'px';p.style.top=(r.top+Math.random()*r.height*.5)+'px';p.style.fontSize=(18+Math.random()*18)+'px';document.body.appendChild(p);setTimeout(()=>p.remove(),1500)}function sprinkle(symbol){for(let i=0;i<12;i++){const s=document.createElement('span');s.className='spark';s.textContent=symbol;s.style.left=(30+Math.random()*40)+'vw';s.style.top=(35+Math.random()*30)+'vh';s.style.fontSize=(15+Math.random()*20)+'px';document.body.appendChild(s);setTimeout(()=>s.remove(),1000)}}document.addEventListener('click',e=>{if(e.target.closest('button,.emoji,.kitty'))return;});

function askKittyTalk(){const phrases=['Mreow? I promise it is a cute surprise! 🐾','May I show you now? Pretty please? 💗','I am guarding the surprise very carefully! 😺','I have a tiny magical delivery ready… ✨'];document.getElementById('permissionSpeech').textContent=phrases[Math.floor(Math.random()*phrases.length)];const k=document.getElementById('askKitty');k.classList.remove('purring');void k.offsetWidth;k.classList.add('purring');kittyDance();sprinkle('💗');}
function notYet(){document.getElementById('permissionSpeech').textContent='No rush! I will guard it with my tiny paws until you are ready. 🌷';document.getElementById('magicMessage').textContent='Mochi is sitting patiently… tap “Yes” whenever you feel ready. 🐾';document.getElementById('magicMessage').classList.add('show');const k=document.getElementById('askKitty');k.animate([{transform:'translateX(0) rotate(0)'},{transform:'translateX(-8px) rotate(-7deg)'},{transform:'translateX(8px) rotate(7deg)'},{transform:'translateX(0) rotate(0)'}],{duration:550});sprinkle('🌸');}
function revealPhoto(){
  const card=document.getElementById('surpriseCard');
  const stage=document.querySelector('.permission-stage');
  const panel=document.getElementById('photoReveal');
  const speech=document.getElementById('permissionSpeech');
  const hint=document.getElementById('arrowHint');
  const buttons=document.querySelector('.permission-buttons');
  const kitty=document.getElementById('askKitty');
  const msg=document.getElementById('magicMessage');
  const orbit=document.getElementById('magicOrbit');
  if(!panel) return;
  if(window.revealStarted) return;
  window.revealStarted=true;
  if(buttons) buttons.style.display='none';
  if(hint) hint.textContent='✨ Mochi is preparing a little bit of magic…';
  if(stage) stage.classList.add('magic-mode');
  if(card) card.classList.add('reveal-mode');
  if(kitty) kitty.classList.add('purring');
  if(orbit) orbit.classList.add('show');
  if(msg){msg.classList.add('show');msg.textContent='Getting your little surprise ready… 💗';}
  if(speech) speech.textContent='Yay! Your surprise is on its way! 🐱💗';
  sprinkle('✨');

  // Make the photo panel visible straight away so it also works reliably on GitHub Pages/mobile.
  panel.classList.add('visible');
  panel.setAttribute('aria-hidden','false');
  const arrow=document.getElementById('arrowFlight');
  if(arrow) arrow.style.animation='arrowFly 1.2s ease-out forwards';
  setTimeout(()=>{
    panel.classList.add('photo-unwrapped');
    if(msg) msg.textContent='Surprise unlocked! Hope this little moment makes you smile. 🌷';
    if(orbit) orbit.classList.remove('show');
    if(speech) speech.textContent='Look! Your photo surprise is here! 💌';
    sprinkle('🌸');
    panel.scrollIntoView({behavior:'smooth',block:'center'});
  },900);
}
